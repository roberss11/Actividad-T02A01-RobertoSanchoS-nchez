let nombre = null;
let ciudad = null;
let pais = null;

function Mostrar() {
    nombre = document.getElementById("nombre").value;
    pais = document.getElementById("país").value;
    ciudad = document.getElementById("ciudad").value;

    Tiempo(nombre, ciudad, pais);
}
function showTiempo( d ) {
	const celsius = Math.round(parseFloat(d.main.temp)-273.15);
	const celsiusMax = Math.round(parseFloat(d.main.temp_max)-273.15);
    const celsiusMin = Math.round(parseFloat(d.main.temp_min)-273.15);
	
	document.getElementById("id-tiempo").innerHTML = "Tiempo en: " + d.name+ "  "+ d.sys.country;
	document.getElementById("id-temp").innerHTML = celsius + '&deg;';
    document.getElementById("id-max").innerHTML = "Max :" + celsiusMax + '&deg;';
    document.getElementById("id-min").innerHTML = "Min :" + celsiusMin + '&deg;';
	
}
function Tiempo( nombre, ciudad, país ) {
	var key = '73d70220a49bfe27e3a7185afdcb17c2';
    let url = `http://api.openweathermap.org/data/2.5/weather?q=${ciudad},${pais}&appid=${key}&lang=es`
	fetch(url)  
	.then((resp) => 
    { 
        return resp.json()
     }) 
	.then((data) => 
    {
        showTiempo(data);
    })
	.catch((error) => {
		Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'La petición no ha podido ser procesada"',
          })
	});
}

